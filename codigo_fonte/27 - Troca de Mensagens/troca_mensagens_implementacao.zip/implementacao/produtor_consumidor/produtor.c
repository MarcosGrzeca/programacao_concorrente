#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>

/*-------------------------------------------------------------------------------------------------------------------------*/
int main(int argc, char **argv){

	struct sockaddr_in endereco_servidor;
	struct sockaddr_in endereco_cliente;
	int soquete_servidor;
	int soquete_cliente;
	int tamanho;
	double item = 0, msg;

	soquete_servidor = socket (AF_INET,SOCK_DGRAM,0);

	bzero((char *)&endereco_servidor,sizeof(endereco_servidor));       
	endereco_servidor.sin_family = AF_INET;
	endereco_servidor.sin_port = htons(atoi(argv[1]));
	endereco_servidor.sin_addr.s_addr = INADDR_ANY;

	bind (soquete_servidor, (struct sockaddr *)&endereco_servidor, sizeof(endereco_servidor));


	while ( 1 ){

		item++;

		tamanho = sizeof(endereco_cliente);
		recvfrom (soquete_servidor, &msg, sizeof(double), 0, (struct sockaddr *)&endereco_cliente, &tamanho);

		msg = item;

		sendto (soquete_servidor, &msg, sizeof(double), 0, (struct sockaddr *)&endereco_cliente, sizeof(endereco_cliente));

	}
 
	close(soquete_servidor);
}
/*-------------------------------------------------------------------------------------------------------------------------*/


