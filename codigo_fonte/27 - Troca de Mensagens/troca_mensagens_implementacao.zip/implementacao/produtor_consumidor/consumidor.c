#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>

/*-------------------------------------------------------------------------------------------------------------------------*/
#define N 5 
/*-------------------------------------------------------------------------------------------------------------------------*/
int main(int argc, char **argv){

	struct sockaddr_in endereco_servidor;
	int soquete;
	double msg, item;	
	int i;

	soquete = socket (AF_INET,SOCK_DGRAM,0);

	bzero((char *)&endereco_servidor,sizeof(endereco_servidor));       
	endereco_servidor.sin_family = AF_INET;
	endereco_servidor.sin_port = htons(atoi(argv[2]));
	endereco_servidor.sin_addr.s_addr = inet_addr(argv[1]);

	for ( i=0; i<N; i++){
		sendto (soquete,&msg, sizeof(double), 0, (struct sockaddr *)&endereco_servidor,sizeof(endereco_servidor));   
	}

	while (1) {

		recvfrom (soquete, &msg, sizeof(double), 0, NULL, NULL );

		item = msg;

		printf("Item: %lf\n", item);

		sendto (soquete,&msg, sizeof(double), 0, (struct sockaddr *)&endereco_servidor,sizeof(endereco_servidor));   

		sleep(10);

	}

	close(soquete);
}
/*-------------------------------------------------------------------------------------------------------------------------*/

